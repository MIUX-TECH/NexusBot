
const express = require('express');
const cors = require('cors');
// Note: In Node 18+, fetch is built-in. If using older Node, install node-fetch.
// const fetch = require('node-fetch'); 

const app = express();
const PORT = 3001;

// Enable CORS for frontend
app.use(cors());
app.use(express.json());

// Bridge Endpoint
app.post('/api/bridge', async (req, res) => {
    const { url, method, headers, body } = req.body;

    console.log(`[BRIDGE] Requesting: ${url}`);

    try {
        const response = await fetch(url, {
            method: method || 'GET',
            headers: headers || {},
            body: body ? JSON.stringify(body) : undefined
        });

        // Capture response text first to debug if needed
        const responseText = await response.text();
        
        // Try parsing JSON, otherwise return text
        let data;
        try {
            data = JSON.parse(responseText);
        } catch (e) {
            data = { msg: responseText };
        }

        // Forward the status code from Binance
        res.status(response.status).json(data);

    } catch (error) {
        console.error("[BRIDGE] Error:", error.message);
        res.status(500).json({ error: error.message, type: 'BRIDGE_ERROR' });
    }
});

app.listen(PORT, () => {
    console.log(`\n🚀 NEXUS TRADING BRIDGE running on http://localhost:${PORT}`);
    console.log(`   Siap melayani request dari Frontend.\n`);
});
